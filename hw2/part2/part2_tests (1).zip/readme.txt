1. Extract the files to part2 dir (override start.sh and compile.sh)
2. Run sudo apt install -y expect
3. Run ./compile.sh
4. Run ./tests/test.exp (when you are on the folder with start.sh)
